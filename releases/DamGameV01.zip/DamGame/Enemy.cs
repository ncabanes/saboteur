﻿/// Enemy - One of the (harmful, pseudo-intelligent, non-static) 
/// items in the game

/* Part of Saboteur Remake
 * 
 * Changes:
 * 0.01, 09-may-2018, Nacho: First version, empty skeleton
 */

namespace DamGame
{
    class Enemy : Sprite
    {
    }
}
