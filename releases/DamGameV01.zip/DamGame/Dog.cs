﻿/// Dog - One of the (harmful) moving items in the game

/* Part of Saboteur Remake
 * 
 * Changes:
 * 0.01, 09-may-2018, Nacho: First version, almost empty skeleton
 */

class Dog : Sprite
{
    public Dog()
    {
        LoadImage("data/imgRetro/dog1r.png");
    }

    public override void Move()
    {
        // TO DO
    }
}
