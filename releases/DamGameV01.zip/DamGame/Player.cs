﻿/// Player - The user-controlled character

/* Part of Saboteur Remake
 * 
 * Changes:
 * 0.01, 09-may-2018, Nacho: First version, empty skeleton
 */

namespace DamGame
{
    class Player : Sprite
    {
    }
}
